/*Criando as tabelas (banco de dados)*/

CREATE TABLE MEDICAMENTO (
    idMedicamento integer PRIMARY KEY,
    nomeMedicamento varchar(150),
    PMVC DECIMAL(10,2),
    necessarioReceita BIT
);

CREATE TABLE SINTOMA (
    idSintoma integer PRIMARY KEY,
    nomeSintoma varchar(150)
);

CREATE TABLE TIPO_CONTATO (
    idTipo integer PRIMARY KEY,
    descriTipoContato varchar(150)
);

CREATE TABLE USUARIO (
    idUsuario integer PRIMARY KEY,
    nomeUsuario varchar(150),
    senha varchar(300),
    dataNascimento date
);

CREATE TABLE ENDERECO (
    idEndereco integer PRIMARY KEY,
    numero integer,
    FK_TIPO_LOGRADOURO_idTipo_Logradouro integer,
    FK_USUARIO_idUsuario integer,
    FK_BAIRRO_idBairro integer
);

CREATE TABLE TIPO_LOGRADOURO (
    idTipo_Logradouro integer PRIMARY KEY,
    descriLogradouro varchar(150)
);

CREATE TABLE BAIRRO (
    idBairro integer PRIMARY KEY,
    descriBairro varchar(300),
    FK_MUNICIPIO_idMunicipio integer
);

CREATE TABLE MUNICIPIO (
    idMunicipio integer PRIMARY KEY,
    descriMunicipio varchar(300),
    FK_ESTADO_idEstado integer
);

CREATE TABLE ESTADO (
    idEstado integer PRIMARY KEY,
    descriEstado varchar(150)
);

CREATE TABLE COMPLEMENTO (
    idComplemento integer PRIMARY KEY,
    descriComplemento varchar(300),
    FK_ENDERECO_idEndereco integer
);

CREATE TABLE MENSAGEM (
    idMensagem integer PRIMARY KEY,
    descriMensagem varchar(500),
    FK_USUARIO_idUsuario integer
);

CREATE TABLE SINTOMA_MEDICAMENTO (
    FK_SINTOMA_idSintoma integer,
    FK_MEDICAMENTO_idMedicamento integer
);

CREATE TABLE USUARIO_TIPO_CONTATO (
    FK_USUARIO_idUsuario integer,
    FK_TIPO_CONTATO_idTipo integer,
    descricao varchar(150)
);

CREATE TABLE SINTOMA_USUARIO (
    FK_SINTOMA_idSintoma integer,
    FK_USUARIO_idUsuario integer,
    dataSintoma date
);
 
ALTER TABLE ENDERECO ADD CONSTRAINT FK_ENDERECO_2
    FOREIGN KEY (FK_TIPO_LOGRADOURO_idTipo_Logradouro)
    REFERENCES TIPO_LOGRADOURO (idTipo_Logradouro)
    ON DELETE RESTRICT;
 
ALTER TABLE ENDERECO ADD CONSTRAINT FK_ENDERECO_3
    FOREIGN KEY (FK_USUARIO_idUsuario)
    REFERENCES USUARIO (idUsuario)
    ON DELETE RESTRICT;
 
ALTER TABLE ENDERECO ADD CONSTRAINT FK_ENDERECO_4
    FOREIGN KEY (FK_BAIRRO_idBairro)
    REFERENCES BAIRRO (idBairro)
    ON DELETE RESTRICT;
 
ALTER TABLE BAIRRO ADD CONSTRAINT FK_BAIRRO_2
    FOREIGN KEY (FK_MUNICIPIO_idMunicipio)
    REFERENCES MUNICIPIO (idMunicipio)
    ON DELETE RESTRICT;
 
ALTER TABLE MUNICIPIO ADD CONSTRAINT FK_MUNICIPIO_2
    FOREIGN KEY (FK_ESTADO_idEstado)
    REFERENCES ESTADO (idEstado)
    ON DELETE RESTRICT;
 
ALTER TABLE COMPLEMENTO ADD CONSTRAINT FK_COMPLEMENTO_2
    FOREIGN KEY (FK_ENDERECO_idEndereco)
    REFERENCES ENDERECO (idEndereco)
    ON DELETE CASCADE;
 
ALTER TABLE MENSAGEM ADD CONSTRAINT FK_MENSAGEM_2
    FOREIGN KEY (FK_USUARIO_idUsuario)
    REFERENCES USUARIO (idUsuario)
    ON DELETE CASCADE;
 
ALTER TABLE SINTOMA_MEDICAMENTO ADD CONSTRAINT FK_SINTOMA_MEDICAMENTO_1
    FOREIGN KEY (FK_SINTOMA_idSintoma)
    REFERENCES SINTOMA (idSintoma)
    ON DELETE RESTRICT;
 
ALTER TABLE SINTOMA_MEDICAMENTO ADD CONSTRAINT FK_SINTOMA_MEDICAMENTO_2
    FOREIGN KEY (FK_MEDICAMENTO_idMedicamento)
    REFERENCES MEDICAMENTO (idMedicamento)
    ON DELETE RESTRICT;
 
ALTER TABLE USUARIO_TIPO_CONTATO ADD CONSTRAINT FK_USUARIO_TIPO_CONTATO_1
    FOREIGN KEY (FK_USUARIO_idUsuario)
    REFERENCES USUARIO (idUsuario)
    ON DELETE RESTRICT;
 
ALTER TABLE USUARIO_TIPO_CONTATO ADD CONSTRAINT FK_USUARIO_TIPO_CONTATO_2
    FOREIGN KEY (FK_TIPO_CONTATO_idTipo)
    REFERENCES TIPO_CONTATO (idTipo)
    ON DELETE SET NULL;
 
ALTER TABLE SINTOMA_USUARIO ADD CONSTRAINT FK_SINTOMA_USUARIO_1
    FOREIGN KEY (FK_SINTOMA_idSintoma)
    REFERENCES SINTOMA (idSintoma)
    ON DELETE SET NULL;
 
ALTER TABLE SINTOMA_USUARIO ADD CONSTRAINT FK_SINTOMA_USUARIO_2
    FOREIGN KEY (FK_USUARIO_idUsuario)
    REFERENCES USUARIO (idUsuario)
    ON DELETE SET NULL;

/*Inserindo os dados*/

INSERT INTO MEDICAMENTO (idMedicamento, nomeMedicamento, PMVC, necessarioReceita) VALUES ('1', 'Algy-Flanderil', '19.26', 'TRUE');
INSERT INTO MEDICAMENTO (idMedicamento, nomeMedicamento, PMVC, necessarioReceita) VALUES ('2', 'Sumax', '75.87', 'TRUE');
INSERT INTO MEDICAMENTO (idMedicamento, nomeMedicamento, PMVC, necessarioReceita) VALUES ('3', 'Simeticona', '12.36', 'FALSE');
INSERT INTO MEDICAMENTO (idMedicamento, nomeMedicamento, PMVC, necessarioReceita) VALUES ('4', 'Paco', '93.06', 'TRUE');
INSERT INTO MEDICAMENTO (idMedicamento, nomeMedicamento, PMVC, necessarioReceita) VALUES ('5', 'Cimetidina', '12.9', 'FALSE');
INSERT INTO MEDICAMENTO (idMedicamento, nomeMedicamento, PMVC, necessarioReceita) VALUES ('6', 'Omeprazol', '31.68', 'FALSE');
INSERT INTO MEDICAMENTO (idMedicamento, nomeMedicamento, PMVC, necessarioReceita) VALUES ('7', 'Vonau', '43.15', 'TRUE');
INSERT INTO MEDICAMENTO (idMedicamento, nomeMedicamento, PMVC, necessarioReceita) VALUES ('8', 'Losartana', '43.78', 'TRUE');
INSERT INTO MEDICAMENTO (idMedicamento, nomeMedicamento, PMVC, necessarioReceita) VALUES ('9', 'Loperamida', '18.9', 'TRUE');
INSERT INTO MEDICAMENTO (idMedicamento, nomeMedicamento, PMVC, necessarioReceita) VALUES ('10', 'Cloridrato de Fexofenadina', '15.74', 'FALSE');
INSERT INTO SINTOMA (idSintoma, nomeSintoma) VALUES ('1', 'Febre'); 
INSERT INTO SINTOMA (idSintoma, nomeSintoma) VALUES ('2', 'Alergia'); 
INSERT INTO SINTOMA (idSintoma, nomeSintoma) VALUES ('3', 'Dor de Cabeça'); 
INSERT INTO SINTOMA (idSintoma, nomeSintoma) VALUES ('4', 'Dores Musculares'); 
INSERT INTO SINTOMA (idSintoma, nomeSintoma) VALUES ('5', 'Dores Intestinais');
INSERT INTO SINTOMA (idSintoma, nomeSintoma) VALUES ('6', 'Gases'); 
INSERT INTO SINTOMA (idSintoma, nomeSintoma) VALUES ('7', 'Vômito'); 
INSERT INTO SINTOMA (idSintoma, nomeSintoma) VALUES ('8', 'Diarréia'); 
INSERT INTO SINTOMA (idSintoma, nomeSintoma) VALUES ('9', 'Pressão'); 
INSERT INTO SINTOMA (idSintoma, nomeSintoma) VALUES ('10', 'Azia'); 
INSERT INTO SINTOMA_MEDICAMENTO(FK_SINTOMA_idSintoma, FK_MEDICAMENTO_idMedicamento) VALUES ('1','1');
INSERT INTO SINTOMA_MEDICAMENTO(FK_SINTOMA_idSintoma, FK_MEDICAMENTO_idMedicamento) VALUES ('2','10');
INSERT INTO SINTOMA_MEDICAMENTO(FK_SINTOMA_idSintoma, FK_MEDICAMENTO_idMedicamento) VALUES ('3','2');
INSERT INTO SINTOMA_MEDICAMENTO(FK_SINTOMA_idSintoma, FK_MEDICAMENTO_idMedicamento) VALUES ('4','4');
INSERT INTO SINTOMA_MEDICAMENTO(FK_SINTOMA_idSintoma, FK_MEDICAMENTO_idMedicamento) VALUES ('5','6');
INSERT INTO SINTOMA_MEDICAMENTO(FK_SINTOMA_idSintoma, FK_MEDICAMENTO_idMedicamento) VALUES ('6','3');
INSERT INTO SINTOMA_MEDICAMENTO(FK_SINTOMA_idSintoma, FK_MEDICAMENTO_idMedicamento) VALUES ('7','7');
INSERT INTO SINTOMA_MEDICAMENTO(FK_SINTOMA_idSintoma, FK_MEDICAMENTO_idMedicamento) VALUES ('8','9');
INSERT INTO SINTOMA_MEDICAMENTO(FK_SINTOMA_idSintoma, FK_MEDICAMENTO_idMedicamento) VALUES ('9','8');
INSERT INTO SINTOMA_MEDICAMENTO(FK_SINTOMA_idSintoma, FK_MEDICAMENTO_idMedicamento) VALUES ('10','5');
INSERT INTO USUARIO (idUsuario, nomeUsuario, senha, dataNascimento) VALUES ('1', 'Raphael ', '1603009414', '2004-02-07');
INSERT INTO USUARIO (idUsuario, nomeUsuario, senha, dataNascimento) VALUES ('2', 'João', 'joaozinhodapaixao', '2004-09-16');
INSERT INTO USUARIO (idUsuario, nomeUsuario, senha, dataNascimento) VALUES ('3', 'Jonathan', '@ignister', '2004-07-12');
INSERT INTO USUARIO (idUsuario, nomeUsuario, senha, dataNascimento) VALUES ('4', 'Vibel', 'otiwngofnbvuiew', '2004-01-23');
INSERT INTO USUARIO (idUsuario, nomeUsuario, senha, dataNascimento) VALUES ('5', 'Moisés', 'nveovnioren', '1981-08-15');
INSERT INTO USUARIO (idUsuario, nomeUsuario, senha, dataNascimento) VALUES ('6', 'Rafael', 'barrosleaoborges', '2001-01-01');
INSERT INTO USUARIO (idUsuario, nomeUsuario, senha, dataNascimento) VALUES ('7', 'Carlos', 'azevedoProf', '1985-09-08');
INSERT INTO USUARIO (idUsuario, nomeUsuario, senha, dataNascimento) VALUES ('8', 'Junior', 'bfueafgifbw', '1989-03-30');
INSERT INTO USUARIO (idUsuario, nomeUsuario, senha, dataNascimento) VALUES ('9', 'Conceição', 'wbfybfyi', '1963-12-24');
INSERT INTO USUARIO (idUsuario, nomeUsuario, senha, dataNascimento) VALUES ('10', 'Isabelle', 'jrevbfubh', '2004-05-28');
INSERT INTO TIPO_CONTATO (idTipo, descriTipoContato) VALUES ('1', 'E-mail');
INSERT INTO TIPO_CONTATO (idTipo, descriTipoContato) VALUES ('2', 'Celular');
INSERT INTO TIPO_CONTATO (idTipo, descriTipoContato) VALUES ('3', 'Facebook');
INSERT INTO TIPO_CONTATO (idTipo, descriTipoContato) VALUES ('4', 'Instagram');
INSERT INTO TIPO_CONTATO (idTipo, descriTipoContato) VALUES ('5', 'Telefone');
INSERT INTO TIPO_CONTATO (idTipo, descriTipoContato) VALUES ('6', 'Tik Tok');
INSERT INTO TIPO_CONTATO (idTipo, descriTipoContato) VALUES ('7', 'Twitter');
INSERT INTO TIPO_CONTATO (idTipo, descriTipoContato) VALUES ('8', 'Skype');
INSERT INTO TIPO_CONTATO (idTipo, descriTipoContato) VALUES ('9', 'Orkut');
INSERT INTO TIPO_CONTATO (idTipo, descriTipoContato) VALUES ('10', 'Discord');
INSERT INTO TIPO_LOGRADOURO (idTipo_Logradouro, descriLogradouro) VALUES ('1', 'Avenida');
INSERT INTO TIPO_LOGRADOURO (idTipo_Logradouro, descriLogradouro) VALUES ('2', 'Alameda');
INSERT INTO TIPO_LOGRADOURO (idTipo_Logradouro, descriLogradouro) VALUES ('3', 'Rua');
INSERT INTO TIPO_LOGRADOURO (idTipo_Logradouro, descriLogradouro) VALUES ('4', 'Condomínio');
INSERT INTO TIPO_LOGRADOURO (idTipo_Logradouro, descriLogradouro) VALUES ('5', 'Rodovia');
INSERT INTO TIPO_LOGRADOURO (idTipo_Logradouro, descriLogradouro) VALUES ('6', 'Estrada');
INSERT INTO TIPO_LOGRADOURO (idTipo_Logradouro, descriLogradouro) VALUES ('7', 'Viela');
INSERT INTO TIPO_LOGRADOURO (idTipo_Logradouro, descriLogradouro) VALUES ('8', 'Praça');
INSERT INTO TIPO_LOGRADOURO (idTipo_Logradouro, descriLogradouro) VALUES ('9', 'Quadra');
INSERT INTO TIPO_LOGRADOURO (idTipo_Logradouro, descriLogradouro) VALUES ('10', 'Morro');
INSERT INTO ESTADO (idEstado, descriEstado) VALUES ('1', 'Espírito Santo');
INSERT INTO ESTADO (idEstado, descriEstado) VALUES ('2', 'Rio de Janeiro');
INSERT INTO ESTADO (idEstado, descriEstado) VALUES ('3', 'São Paulo');
INSERT INTO ESTADO (idEstado, descriEstado) VALUES ('4', 'Minas Gerais');
INSERT INTO ESTADO (idEstado, descriEstado) VALUES ('5', 'Pernambuco');
INSERT INTO ESTADO (idEstado, descriEstado) VALUES ('6', 'Sergipe');
INSERT INTO ESTADO (idEstado, descriEstado) VALUES ('7', 'Paraná');
INSERT INTO ESTADO (idEstado, descriEstado) VALUES ('8', 'Góias');
INSERT INTO ESTADO (idEstado, descriEstado) VALUES ('9', 'Amazonas');
INSERT INTO ESTADO (idEstado, descriEstado) VALUES ('10', 'Roraima');
INSERT INTO MUNICIPIO (idMunicipio, descriMunicipio, FK_ESTADO_idEstado) VALUES ('1', 'Serra', '1');
INSERT INTO MUNICIPIO (idMunicipio, descriMunicipio, FK_ESTADO_idEstado) VALUES ('2', 'Vitória', '1');
INSERT INTO MUNICIPIO (idMunicipio, descriMunicipio, FK_ESTADO_idEstado) VALUES ('3', 'Cariacica', '1');
INSERT INTO MUNICIPIO (idMunicipio, descriMunicipio, FK_ESTADO_idEstado) VALUES ('4', 'Vila Velha', '1');
INSERT INTO MUNICIPIO (idMunicipio, descriMunicipio, FK_ESTADO_idEstado) VALUES ('5', 'Fundão', '1');
INSERT INTO MUNICIPIO (idMunicipio, descriMunicipio, FK_ESTADO_idEstado) VALUES ('6', 'Viana', '1');
INSERT INTO MUNICIPIO (idMunicipio, descriMunicipio, FK_ESTADO_idEstado) VALUES ('7', 'Santa Teresa', '1');
INSERT INTO MUNICIPIO (idMunicipio, descriMunicipio, FK_ESTADO_idEstado) VALUES ('8', 'Boa Eesperança', '1');
INSERT INTO MUNICIPIO (idMunicipio, descriMunicipio, FK_ESTADO_idEstado) VALUES ('9', 'Nova Venécia', '1');
INSERT INTO MUNICIPIO (idMunicipio, descriMunicipio, FK_ESTADO_idEstado) VALUES ('10', 'Cachoeiro de Itapemerim', '1');
INSERT INTO BAIRRO (idBairro, descriBairro, FK_MUNICIPIO_idMunicipio) VALUES ('1', 'Valparaíso', '1');
INSERT INTO BAIRRO (idBairro, descriBairro, FK_MUNICIPIO_idMunicipio) VALUES ('2', 'Morada de Laranjeiras', '1');
INSERT INTO BAIRRO (idBairro, descriBairro, FK_MUNICIPIO_idMunicipio) VALUES ('3', 'Olaria', '4');
INSERT INTO BAIRRO (idBairro, descriBairro, FK_MUNICIPIO_idMunicipio) VALUES ('4', 'Novo Horizonte', '1');
INSERT INTO BAIRRO (idBairro, descriBairro, FK_MUNICIPIO_idMunicipio) VALUES ('5', 'Praia da Costa', '4');
INSERT INTO BAIRRO (idBairro, descriBairro, FK_MUNICIPIO_idMunicipio) VALUES ('6', 'Jardim Camburi', '2');
INSERT INTO BAIRRO (idBairro, descriBairro, FK_MUNICIPIO_idMunicipio) VALUES ('7', 'Bento Ferreira', '2');
INSERT INTO BAIRRO (idBairro, descriBairro, FK_MUNICIPIO_idMunicipio) VALUES ('8', 'Feu Rosa', '1');
INSERT INTO BAIRRO (idBairro, descriBairro, FK_MUNICIPIO_idMunicipio) VALUES ('9', 'Campo Grande', '3');
INSERT INTO BAIRRO (idBairro, descriBairro, FK_MUNICIPIO_idMunicipio) VALUES ('10', 'Patrimônio', '7');
INSERT INTO ENDERECO (idEndereco, numero, FK_TIPO_LOGRADOURO_idTipo_Logradouro, FK_USUARIO_idUsuario, FK_BAIRRO_idBairro) VALUES ('1', '260', '1', '2', '3');
INSERT INTO ENDERECO (idEndereco, numero, FK_TIPO_LOGRADOURO_idTipo_Logradouro, FK_USUARIO_idUsuario, FK_BAIRRO_idBairro) VALUES ('2', '790', '2', '1', '1');
INSERT INTO ENDERECO (idEndereco, numero, FK_TIPO_LOGRADOURO_idTipo_Logradouro, FK_USUARIO_idUsuario, FK_BAIRRO_idBairro) VALUES ('3', '310', '3', '6', '5');
INSERT INTO ENDERECO (idEndereco, numero, FK_TIPO_LOGRADOURO_idTipo_Logradouro, FK_USUARIO_idUsuario, FK_BAIRRO_idBairro) VALUES ('4', '32', '4', '3', '4');
INSERT INTO ENDERECO (idEndereco, numero, FK_TIPO_LOGRADOURO_idTipo_Logradouro, FK_USUARIO_idUsuario, FK_BAIRRO_idBairro) VALUES ('5', '54', '5', '4', '2');
INSERT INTO ENDERECO (idEndereco, numero, FK_TIPO_LOGRADOURO_idTipo_Logradouro, FK_USUARIO_idUsuario, FK_BAIRRO_idBairro) VALUES ('6', '100', '6', '5', '2');
INSERT INTO ENDERECO (idEndereco, numero, FK_TIPO_LOGRADOURO_idTipo_Logradouro, FK_USUARIO_idUsuario, FK_BAIRRO_idBairro) VALUES ('7', '6', '7', '10', '7');
INSERT INTO ENDERECO (idEndereco, numero, FK_TIPO_LOGRADOURO_idTipo_Logradouro, FK_USUARIO_idUsuario, FK_BAIRRO_idBairro) VALUES ('8', '8', '8', '7', '8');
INSERT INTO ENDERECO (idEndereco, numero, FK_TIPO_LOGRADOURO_idTipo_Logradouro, FK_USUARIO_idUsuario, FK_BAIRRO_idBairro) VALUES ('9', '67', '9', '8', '9');
INSERT INTO ENDERECO (idEndereco, numero, FK_TIPO_LOGRADOURO_idTipo_Logradouro, FK_USUARIO_idUsuario, FK_BAIRRO_idBairro) VALUES ('10', '93', '10', '9', '10');
INSERT INTO COMPLEMENTO (idComplemento, descriComplemento, FK_ENDERECO_idEndereco) VALUES ('1', 'Próximo ao Parque da Cidade', '2');
INSERT INTO COMPLEMENTO (idComplemento, descriComplemento, FK_ENDERECO_idEndereco) VALUES ('2', 'Próximo ao IFES Serra', '6');
INSERT INTO COMPLEMENTO (idComplemento, descriComplemento, FK_ENDERECO_idEndereco) VALUES ('3', 'Final da Rua Castelo Branco', '1');
INSERT INTO COMPLEMENTO (idComplemento, descriComplemento, FK_ENDERECO_idEndereco) VALUES ('4', 'Perto do Shopping', '4');
INSERT INTO COMPLEMENTO (idComplemento, descriComplemento, FK_ENDERECO_idEndereco) VALUES ('5', 'Ao lado do trailer preto', '5');
INSERT INTO COMPLEMENTO (idComplemento, descriComplemento, FK_ENDERECO_idEndereco) VALUES ('6', 'Na frente da indústria murundu', '7');
INSERT INTO COMPLEMENTO (idComplemento, descriComplemento, FK_ENDERECO_idEndereco) VALUES ('7', 'Em frente ao Boulevard Lagoa', '8');
INSERT INTO COMPLEMENTO (idComplemento, descriComplemento, FK_ENDERECO_idEndereco) VALUES ('8', 'Perto da terceira ponte', '3');
INSERT INTO COMPLEMENTO (idComplemento, descriComplemento, FK_ENDERECO_idEndereco) VALUES ('9', 'Em cima do Bar da Zilda', '9');
INSERT INTO COMPLEMENTO (idComplemento, descriComplemento, FK_ENDERECO_idEndereco) VALUES ('10', 'Próximo ao IFES Santa Teresa', '10');
INSERT INTO MENSAGEM (idMensagem, descriMensagem, FK_USUARIO_idUsuario) VALUES ('1', 'Parabéns pelo site, encontrei meu medicamento', '1');
INSERT INTO MENSAGEM (idMensagem, descriMensagem, FK_USUARIO_idUsuario) VALUES ('2', 'Não gostei, faltam muitas coisas para ser melhor', '2');
INSERT INTO MENSAGEM (idMensagem, descriMensagem, FK_USUARIO_idUsuario) VALUES ('3', 'Poderia colocar mais sintomas e medicamentos', '3');
INSERT INTO MENSAGEM (idMensagem, descriMensagem, FK_USUARIO_idUsuario) VALUES ('4', 'Gostei da dinamicidade do site', '4');
INSERT INTO MENSAGEM (idMensagem, descriMensagem, FK_USUARIO_idUsuario) VALUES ('5', 'Site bom', '5');
INSERT INTO MENSAGEM (idMensagem, descriMensagem, FK_USUARIO_idUsuario) VALUES ('6', 'Poderia ter mais coisas no site', '6');
INSERT INTO MENSAGEM (idMensagem, descriMensagem, FK_USUARIO_idUsuario) VALUES ('7', 'Lixo, muito poucas opções', '7');
INSERT INTO MENSAGEM (idMensagem, descriMensagem, FK_USUARIO_idUsuario) VALUES ('8', 'Adorei, por que não tiveram essa ideia antes?', '8');
INSERT INTO MENSAGEM (idMensagem, descriMensagem, FK_USUARIO_idUsuario) VALUES ('9', 'Eu só queria agradecer pela engenhosa ideia de colocar o PMVC', '9');
INSERT INTO MENSAGEM (idMensagem, descriMensagem, FK_USUARIO_idUsuario) VALUES ('10', 'Pouco intuitivo', '10');
INSERT INTO SINTOMA_USUARIO (FK_SINTOMA_idSintoma, FK_USUARIO_idUsuario, dataSintoma) VALUES ('1', '1', '2020-02-28');
INSERT INTO SINTOMA_USUARIO (FK_SINTOMA_idSintoma, FK_USUARIO_idUsuario, dataSintoma) VALUES ('2', '2', '2022-06-01');
INSERT INTO SINTOMA_USUARIO (FK_SINTOMA_idSintoma, FK_USUARIO_idUsuario, dataSintoma) VALUES ('3', '3', '2021-08-11');
INSERT INTO SINTOMA_USUARIO (FK_SINTOMA_idSintoma, FK_USUARIO_idUsuario, dataSintoma) VALUES ('4', '4', '2022-12-25');
INSERT INTO SINTOMA_USUARIO (FK_SINTOMA_idSintoma, FK_USUARIO_idUsuario, dataSintoma) VALUES ('5', '5', '2020-05-31');
INSERT INTO SINTOMA_USUARIO (FK_SINTOMA_idSintoma, FK_USUARIO_idUsuario, dataSintoma) VALUES ('6', '6', '2022-04-12');
INSERT INTO SINTOMA_USUARIO (FK_SINTOMA_idSintoma, FK_USUARIO_idUsuario, dataSintoma) VALUES ('7', '7', '2021-09-16');
INSERT INTO SINTOMA_USUARIO (FK_SINTOMA_idSintoma, FK_USUARIO_idUsuario, dataSintoma) VALUES ('8', '8', '2022-02-07');
INSERT INTO SINTOMA_USUARIO (FK_SINTOMA_idSintoma, FK_USUARIO_idUsuario, dataSintoma) VALUES ('9', '9', '2021-09-11');
INSERT INTO SINTOMA_USUARIO (FK_SINTOMA_idSintoma, FK_USUARIO_idUsuario, dataSintoma) VALUES ('10', '10', '2020-08-31');
INSERT INTO USUARIO_TIPO_CONTATO (FK_USUARIO_idUsuario, FK_TIPO_CONTATO_idTipo, descricao) VALUES ('1', '1', 'raphaelbranco2004@gmail.com');
INSERT INTO USUARIO_TIPO_CONTATO (FK_USUARIO_idUsuario, FK_TIPO_CONTATO_idTipo, descricao) VALUES ('2', '2', '(27)992696036');
INSERT INTO USUARIO_TIPO_CONTATO (FK_USUARIO_idUsuario, FK_TIPO_CONTATO_idTipo, descricao) VALUES ('3', '3', 'Jonathan Castro');
INSERT INTO USUARIO_TIPO_CONTATO (FK_USUARIO_idUsuario, FK_TIPO_CONTATO_idTipo, descricao) VALUES ('4', '4', '@vibeloficial ');
INSERT INTO USUARIO_TIPO_CONTATO (FK_USUARIO_idUsuario, FK_TIPO_CONTATO_idTipo, descricao) VALUES ('5', '5', '(27)33289661');
INSERT INTO USUARIO_TIPO_CONTATO (FK_USUARIO_idUsuario, FK_TIPO_CONTATO_idTipo, descricao) VALUES ('6', '6', '@tiktokdoRafa');
INSERT INTO USUARIO_TIPO_CONTATO (FK_USUARIO_idUsuario, FK_TIPO_CONTATO_idTipo, descricao) VALUES ('7', '7', '@CarlosTwiteiro');
INSERT INTO USUARIO_TIPO_CONTATO (FK_USUARIO_idUsuario, FK_TIPO_CONTATO_idTipo, descricao) VALUES ('8', '8', 'junior');
INSERT INTO USUARIO_TIPO_CONTATO (FK_USUARIO_idUsuario, FK_TIPO_CONTATO_idTipo, descricao) VALUES ('9', '1', 'conceicaoaraujo@hotmail.com ');
INSERT INTO USUARIO_TIPO_CONTATO (FK_USUARIO_idUsuario, FK_TIPO_CONTATO_idTipo, descricao) VALUES ('10', '2', '(27)995765826');
